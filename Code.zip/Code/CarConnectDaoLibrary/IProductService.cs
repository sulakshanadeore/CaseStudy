﻿using CarConnectEntityLibary;
namespace CarConnectDaoLibrary
{
    public interface IProductService
    {
        //Add reference of EntityLibrary in DAO
      public  ProductsEntity GetProductByID(int prodid);
        public ProductsEntity GetProductByName(string productName);
        public void AddProduct(ProductsEntity product); 
        public void UpdateProduct(ProductsEntity product);
        public void DeleteProduct(int prodid);
        public List<ProductsEntity> GetAllProducts();


    }
}
