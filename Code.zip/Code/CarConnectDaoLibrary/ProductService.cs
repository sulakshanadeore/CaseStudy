﻿using CarConnectEntityLibary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarConnectExceptionLibrary;
using CarConnectUtilLibrary;
using Microsoft.Data.SqlClient;

namespace CarConnectDaoLibrary
{
    public class ProductService : IProductService
    {
        public void AddProduct(ProductsEntity product)
        {



            //StringBuilder sb = new StringBuilder();
            //ProductsEntity p=new ProductsEntity();
            //p.ProductName=product.ProductName;
            //p.QuantityPerUnit = product.QuantityPerUnit;
            //p.UnitPrice = product.UnitPrice;    
            //p.Discontinued  =product.Discontinued;  
            //p.CategoryID = product.CategoryID;
            //p.SupplierID = product.SupplierID;  
            //p.ReorderLevel = product.ReorderLevel;
            //p.UnitsInStock = product.UnitsInStock;
            //p.UnitsOnOrder = product.UnitsOnOrder;

            //  sb.Append("insert into Products values(" + product.ProductName + "," + product.SupplierID + "," + product.CategoryID + "," + product.QuantityPerUnit + "," + product.UnitPrice + "," + product.UnitsInStock + "," + product.UnitsOnOrder + "," + product.ReorderLevel + "," + product.Discontinued + ")");
            SqlConnection cn = DBPropertyUtil.AppConnection();
            SqlCommand cmd = new SqlCommand("dbo.InsertProductData",cn);
            cn.Open();
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
           
            cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
            cmd.Parameters.AddWithValue("@QuantityPerUnit",product.QuantityPerUnit);
            cmd.Parameters.AddWithValue("@UnitPrice", product.UnitPrice);
            cmd.Parameters.AddWithValue("@CategoryID", product.CategoryID);
            cmd.Parameters.AddWithValue("@SupplierID", product.SupplierID);
            cmd.Parameters.AddWithValue("@ReorderLevel", product.ReorderLevel);
            cmd.Parameters.AddWithValue("@UnitsInStock", product.UnitsInStock);
            cmd.Parameters.AddWithValue("@UnitsOnOrder", product.UnitsOnOrder);
            cmd.Parameters.AddWithValue("@Discontinued", product.Discontinued);
          
            cmd.ExecuteNonQuery();//insert/update/delete ---executenonquery
            
            cmd.Dispose();  
            cn.Close();
            cn.Dispose();

        }

        public void DeleteProduct(int prodid)
        {
            SqlConnection cn = DBPropertyUtil.AppConnection();
            SqlCommand cmd = new SqlCommand("Delete from DemoProducts where Productid=@prodid", cn);
            cmd.Parameters.AddWithValue("@prodid",prodid);
            cn.Open();
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
        }

        public ProductsEntity GetProductByID(int prodid)
        {
            ProductsEntity product = new ProductsEntity();
            SqlConnection cn = DBPropertyUtil.AppConnection();
            SqlCommand cmd = new SqlCommand("Select *  from DemoProducts where Productid=@prodid", cn);
            
            cn.Open();
            cmd.Parameters.AddWithValue("@prodid", prodid);
            SqlDataReader dr=cmd.ExecuteReader();

            //while (dr.Read()) 
            //{
            if (dr.HasRows)
            {
                product.Productid = Convert.ToInt32(dr["ProductID"]);
                product.ProductName = dr["ProductName"].ToString();
                product.UnitPrice = Convert.ToInt32(dr["Price"]);
            }
            //else
            //{
            //    throw new ProductNotFoundException("Can't find this productidd");
            //}
            //}
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
            if (product != null) { 
            return product;
       
            }
            else
            {
                throw new ProductNotFoundException("Pls check productid");
            }
        }

        public ProductsEntity GetProductByName(string productName)
        {

            ProductsEntity product = new ProductsEntity();

            SqlConnection cn = DBPropertyUtil.AppConnection();
            SqlCommand cmd = new SqlCommand("Select *  from DemoProducts where ProductName=@productName", cn);
            cmd.Parameters.AddWithValue("@productName", productName);
            cn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                product.Productid = Convert.ToInt32(dr["ProductID"]);
                product.ProductName = dr["ProductName"].ToString();
                product.UnitPrice = Convert.ToInt32(dr["Price"]);



            }
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
            if (product != null)
            {
                return product;


            }
            else
            {
                throw new ProductNotFoundException("Pls check productid");
            }



        }


        public List<ProductsEntity> GetAllProducts()
        {
            List<ProductsEntity> productList = new List<ProductsEntity>();
           
            SqlConnection cn = DBPropertyUtil.AppConnection();
            SqlCommand cmd = new SqlCommand("Select *  from DemoProducts", cn);
            cn.Open();
            SqlDataReader dr = cmd.ExecuteReader();//select
            //SqlDataReader is a readonly forward only stream of data 
            while (dr.Read())//dr.read reads one row
            {
                ProductsEntity  product = new ProductsEntity();
                product.Productid = Convert.ToInt32(dr["ProductID"]);
                product.ProductName = dr["ProductName"].ToString();
                product.UnitPrice = Convert.ToInt32(dr["Price"]);

                productList.Add(product);
           }
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
            return productList;


        }

        public void UpdateProduct(ProductsEntity product)
        {
            //    SqlConnection cn = DBPropertyUtil.AppConnection();
            SqlConnection cn = new SqlConnection(" server=.\\sqlexpress;integrated security=true;trust server certificate=true;database=NorthwindOriginal");
            //SqlCommand for sql command---insert/update/delete/select and cn
            SqlCommand cmd = new SqlCommand("dbo.sp_UpdateProductData", cn);
            cn.Open();
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@pid", product.Productid);
            cmd.Parameters.AddWithValue("@pname", product.ProductName);
            cmd.Parameters.AddWithValue("@prodprice", product.UnitPrice);
            
            
            int cnt=cmd.ExecuteNonQuery();//insert/update/delete ---executenonquery

            cmd.Dispose();
            cn.Close();
            cn.Dispose();



        }



    }
}
