﻿using CarConnectDaoLibrary;
using CarConnectEntityLibary;
namespace HelperLibrary
{
    public class ProductsServiceHelper
    {
        ProductService service = null;
        public ProductsServiceHelper()
        {
             service = new ProductService();
        }

        public void InsertProduct(ProductsEntity p)
        { 
            service.AddProduct(p);  
        
        }

        public void UpdateProduct(ProductsEntity p)
        {
            service.UpdateProduct(p);

        }

        public void DeleteProduct(int productid) { 
        service.DeleteProduct(productid);
        
        }


        public ProductsEntity FindProductByID(int productid)
        {
            ProductsEntity product = new ProductsEntity();
            try
            {
                 product = service.GetProductByID(productid);
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return product;
        }


        public ProductsEntity FindProductByName(string productname)
        {
            ProductsEntity product = new ProductsEntity();
            try
            {
                product = service.GetProductByName(productname);
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return product;
        }

        public List<ProductsEntity> ListOfAllProducts() 
        { 
        
        List<ProductsEntity> productsList=service.GetAllProducts();
        return productsList;
        }




    }
}
