﻿using CarConnectEntityLibary;
using HelperLibrary;
internal class Program
{
    private static void Main(string[] args)
    {
     
        Console.WriteLine("Menu");
        Console.WriteLine("1.Add 2 Update 3 Delete 4 Find ById 5. Find By Name   6.Show All Products 7.Exit");

        int userchoice = Convert.ToInt32(Console.ReadLine());

        switch (userchoice)
        {

            case 1:
                InsertProduct();
                break;
            case 2:
                ProductsEntity productentity = new ProductsEntity();
                Console.WriteLine("Enter Product id");
                productentity.Productid = Convert.ToInt32(Console.ReadLine());  
                Console.WriteLine("Enter Productname");
                productentity.ProductName = Console.ReadLine();
                Console.WriteLine("enter price");
                productentity.UnitPrice = Convert.ToDecimal(Console.ReadLine());

                ProductsServiceHelper helper1    = new ProductsServiceHelper();  
                helper1.UpdateProduct(productentity);


                break;
                case 3:
                Console.WriteLine("Enter productid ");
                int prodid=Convert.ToInt32(Console.ReadLine());
                ProductsServiceHelper delhelper = new ProductsServiceHelper();
                delhelper.DeleteProduct(prodid);




                break;
            case 4:
                Console.WriteLine("Enter productid ");
                 prodid = Convert.ToInt32(Console.ReadLine());
                ProductsServiceHelper findhelper = new ProductsServiceHelper();
                ProductsEntity productData=findhelper.FindProductByID(prodid);
                Console.WriteLine(productData.Productid);
                Console.WriteLine(productData.ProductName);
                Console.WriteLine(productData.UnitPrice);





                break;
            case 5:
                Console.WriteLine("Enter productname ");
              string  prodname = Console.ReadLine();
                ProductsServiceHelper findhelperbyname = new ProductsServiceHelper();
                productData = findhelperbyname.FindProductByName(prodname);
                Console.WriteLine(productData.Productid);
                Console.WriteLine(productData.ProductName);
                Console.WriteLine(productData.UnitPrice);



                break;
                case 6:
                ProductsServiceHelper helper2 = new ProductsServiceHelper();
               List<ProductsEntity> plist =helper2.ListOfAllProducts();
                foreach (var item in plist)
                {
                    Console.WriteLine(item.Productid);
                    Console.WriteLine(item.ProductName);
                    Console.WriteLine(item.UnitPrice);
                }

                break;
                case 7:
                Environment.Exit(1);
                    break;

            default:
                break;
        }

        
    }

    private static void InsertProduct()
    {
        ProductsEntity productentity = new ProductsEntity();
        Console.WriteLine("Enter Productname");
        productentity.ProductName = Console.ReadLine();
        Console.WriteLine("Enter Supplierid");
        productentity.SupplierID = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter categoryid");
        productentity.CategoryID = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter quantity per unit");
        productentity.QuantityPerUnit = Console.ReadLine();
        Console.WriteLine("enter price");
        productentity.UnitPrice = Convert.ToDecimal(Console.ReadLine());
        Console.WriteLine("Enter Units in Stock");
        productentity.UnitsInStock = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter Units on ORders"); productentity.UnitsOnOrder = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter reorder level");
        productentity.ReorderLevel = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter disconitued or not");
        productentity.Discontinued = Convert.ToBoolean(Console.ReadLine());
        ProductsServiceHelper helper = new ProductsServiceHelper();
        helper.InsertProduct(productentity);
    }
}