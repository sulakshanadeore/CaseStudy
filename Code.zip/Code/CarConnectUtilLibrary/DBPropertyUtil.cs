﻿using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Reflection.Metadata;
using Microsoft.Data.SqlClient;

namespace CarConnectUtilLibrary
{
    public class DBPropertyUtil
    {

   
        public static SqlConnection  AppConnection()
        {
           string cnstring= GetConnectionString();
        SqlConnection cn=new SqlConnection(cnstring);
            return cn;
        
        }

        public static string GetConnectionString() {
            return "server=.\\sqlexpress;database=NorthwindOriginal;integrated security=true;trust server certificate=true";


        }

  }
}
